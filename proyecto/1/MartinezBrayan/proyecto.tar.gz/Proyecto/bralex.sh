#!/bin/bash


function encrypt(){
	
	if [ $2 -eq 0 ]
	then
		lines=$( wc $1 | cut -d' ' -f2 )
		Tipo_alfa=$( tail -n 1 $1 | cut -c2- | cut -d: -f1 )
		Dato=$( tail -n 1 $1 | cut -c2- | cut -d: -f2 )
		
		if [ $Tipo_alfa = "ascii" ]
		then
			FirstLetter=$(printf \\$(printf "%03o" "$Dato"))
			let LastNumber=Dato-1
			LastLetter=$(printf \\$(printf "%03o" "$LastNumber"))
			cat $1 | tr [A-Z] [a-z] | tr ["$FirstLetter"-za-"$LastLetter"] [a-z] > /tmp/$1.d
		else
			cat $1 | tr [A-Z] [a-z] | tr $Dato [a-z] > /tmp/$1.d
		fi	
	
 		sed -i "$lines""d" /tmp/$1.d

		if [ $5 -eq 1 ]
		then
			echo "COMPILANDO OTRO PROGRAMA"
			bash /tmp/$1.d
			
		else
			cp /tmp/$1.d $PWD/$1	
		fi
			rm -f /tmp/$1.d
	else
		if [ $4 = "ascii" ]
		then 	
	
			let FirstNumber=$3%25
			let FirstNumber=$FirstNumber+97
		
			FirstLetter=$(printf \\$(printf "%03o" "$FirstNumber"))
			let LastNumber=FirstNumber-1

			if [ $LastNumber -eq -1 ]
			then
				LastLetter="z"
			else	
				LastLetter=$(printf \\$(printf "%03o" "$LastNumber"))
			fi

			cat $1 | tr [A-Z] [a-z] | tr [a-z] ["$FirstLetter"-za-"$LastLetter"] > $1
			echo "#ascii:$FirstNumber" >> $1

		else
			cat $1 | tr [A-Z] [a-z] | tr [a-z] $4 > $1
			echo "#other:$4" >> $1
		fi
	fi
}


ENCRYPT_STATE=1
DESPLAZAMIENTO=4
ALPHABET="ascii"
COMPILAR=0

# Mientras el número de argumentos NO SEA 0
while [ $# -ne 1 ]
do
    case "$1" in
    -e|--encrypt)
        ENCRYPT_STATE=1
        ;;
    -d|--decrypt)
       	ENCRYPT_STATE=0
        ;;
    -s|--sequence)
	DESPLAZAMIENTO="$2"
	shift
        ;;
    -a|--alphabet)
        ALPHABET="$2"
	shift
        ;;
    -c|--compile)
	COMPILAR=1
	;;
    *)
        echo "Argumento no válido"
        ;;
    esac
    shift
done

#en este momento sale del while y toma el valor del ultimo argumento que 
#sera el nombre del archivo


ARCHIVO_SCRYPT="$1"

if [ $COMPILAR -eq 1 ]
then
	ENCRYPT_STATE=0
fi

if [ -e "$ARCHIVO_SCRYPT" ]
then
	encrypt "$ARCHIVO_SCRYPT" "$ENCRYPT_STATE" "$DESPLAZAMIENTO" "$ALPHABET" "$COMPILAR"
else
	echo "El archivo $ARCHIVO_SCRYPT no existe"
fi

	


