Para instalar el comando y el man se deben tener los siguientes archivos en la misma ubicación (directorio):
-ce.1
-ce
-instalar.sh 

Se cambian los permisos de ejecución para lo cual se ejecuta la siguiente linea
chmod 755 instalar.sh

A continuación se ejecuta el script 
./instalar.sh

Y estará listo el comando y el man para ejecutarse :)