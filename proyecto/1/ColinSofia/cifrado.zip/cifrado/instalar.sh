#!/bin/bash

sudo cp ce /bin/ce
sudo cp ce.1  /usr/share/man/man1/ce.1

