# Proyecto 1: Cifrado César(Bralex)
````
Entrega: 14/04/2019
Hora límite: 23:59
````
## Objetivos
* El alumno aprenderá a crear comandos a partir de shell script 
* El alumno aprenderá a crear un man page.

## Introducción
En criptografía, el cifrado César, también conocido como cifrado por desplazamiento, es una de las técnicas de cifrado más simples y más usadas. Es un tipo de cifrado por sustitución en el que una letra en el texto original es reemplazada por otra que se encuentra un número fijo de posiciones más adelante en el alfabeto. 

**Ejemplo**  
Alfabeto: 'a-z'  
Desplazamiento: 4  
Frase a cifrar: Hay una serpiente en mi bota  
Frase cifrada: Lec yre wivtmirxi ir pm fsxe  

## Instalacion    
##### Requerimientos
* Sistema centos
* Ejecutar comandos como usuario root

El primer paso sera mover extraer nuestros archivos
```sh
$ tar -xzvf proyecto.tar.gz
```
posteriormente entramos al directorio y ejecutamos el siguiente comando 
```sh
$ cp bralex.1.gz /usr/share/man/man1
```
Esto pondrá nuestro man page disponible
Finalmente se instala el comando en bin
```sh
$ cp bralex /usr/loca/bin
```
Ahora si, listo para usar

